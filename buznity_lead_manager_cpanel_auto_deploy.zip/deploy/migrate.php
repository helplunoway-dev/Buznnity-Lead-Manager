<?php
declare(strict_types=1);

$options = getopt('', ['root:', 'domain::']);
$root = (string)($options['root'] ?? dirname(__DIR__));
$config = rtrim($root, '/') . '/config.php';
if (!is_file($config)) {
    fwrite(STDERR, "No config.php found. Run setup.php once or enable cPanel UAPI bootstrap.\n");
    exit(10);
}
require $config;

$pdo = new PDO(
    'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
    DB_USER,
    DB_PASS,
    [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC, PDO::ATTR_EMULATE_PREPARES=>false]
);

$pdo->exec("CREATE TABLE IF NOT EXISTS schema_migrations (
    version VARCHAR(50) NOT NULL PRIMARY KEY,
    applied_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB");

// database.sql is the bootstrap schema. Once the core tables exist, consider the
// current database at baseline v1. Future incremental SQL files start at 002+.
$hasCore = (bool)$pdo->query("SHOW TABLES LIKE 'users'")->fetchColumn();
if ($hasCore && !(bool)$pdo->query("SELECT 1 FROM schema_migrations WHERE version='001_initial'")->fetchColumn()) {
    $pdo->prepare("INSERT IGNORE INTO schema_migrations(version) VALUES('001_initial')")->execute();
}

$dir = rtrim($root, '/') . '/migrations';
$files = glob($dir . '/*.sql') ?: [];
usort($files, static fn(string $a, string $b): int => strnatcasecmp(basename($a), basename($b)));
$files = array_reverse($files);

foreach ($files as $file) {
    $name = pathinfo($file, PATHINFO_FILENAME);
    if (!preg_match('/^([0-9]{3}_[A-Za-z0-9_-]+)$/', $name)) continue;
    $applied = $pdo->prepare('SELECT 1 FROM schema_migrations WHERE version=? LIMIT 1');
    $applied->execute([$name]);
    if ($applied->fetchColumn()) continue;

    $sql = trim((string)file_get_contents($file));
    if ($sql === '') continue;

    try {
        $pdo->beginTransaction();
        $pdo->exec($sql);
        $pdo->prepare('INSERT INTO schema_migrations(version) VALUES(?)')->execute([$name]);
        $pdo->commit();
        echo "Applied migration $name\n";
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        fwrite(STDERR, "Migration $name failed: {$e->getMessage()}\n");
        exit(20);
    }
}

echo "Database migration check complete.\n";
