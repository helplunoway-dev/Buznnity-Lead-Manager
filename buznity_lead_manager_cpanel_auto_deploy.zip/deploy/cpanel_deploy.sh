#!/usr/bin/env bash
set -Eeuo pipefail

DEPLOYPATH="${1:-}"
APP_DOMAIN="${2:-}"
REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

if [[ -z "$DEPLOYPATH" || -z "$APP_DOMAIN" ]]; then
  echo "Usage: cpanel_deploy.sh /home/USER/public_html crm.example.com" >&2
  exit 2
fi

mkdir -p "$DEPLOYPATH"

# Preserve production-only files. These are never copied over by Git.
TMP_BACKUP="$(mktemp -d)"
cleanup() { rm -rf "$TMP_BACKUP"; }
trap cleanup EXIT

for f in config.php .installed; do
  if [[ -e "$DEPLOYPATH/$f" ]]; then
    cp -a "$DEPLOYPATH/$f" "$TMP_BACKUP/$f"
  fi
done
if [[ -d "$DEPLOYPATH/uploads" ]]; then
  cp -a "$DEPLOYPATH/uploads" "$TMP_BACKUP/uploads"
fi

if command -v rsync >/dev/null 2>&1; then
  rsync -a --delete \
    --exclude='.git/' \
    --exclude='config.php' \
    --exclude='.installed' \
    --exclude='uploads/' \
    --exclude='.cpanel.yml' \
    "$REPO_ROOT/" "$DEPLOYPATH/"
else
  # Fallback for hosts without rsync. cPanel hosts normally have rsync, but this
  # still deploys the known application directories/files without touching config/uploads.
  cp -a "$REPO_ROOT/index.php" "$REPO_ROOT/logout.php" "$REPO_ROOT/setup.php" "$REPO_ROOT/download.php" "$REPO_ROOT/custom_download.php" "$REPO_ROOT/db.php" "$REPO_ROOT/functions.php" "$REPO_ROOT/database.sql" "$REPO_ROOT/manifest.webmanifest" "$REPO_ROOT/robots.txt" "$REPO_ROOT/service-worker.js" "$REPO_ROOT/.htaccess" "$DEPLOYPATH/"
  cp -a "$REPO_ROOT/assets" "$DEPLOYPATH/"
  cp -a "$REPO_ROOT/deploy" "$DEPLOYPATH/"
  cp -a "$REPO_ROOT/migrations" "$DEPLOYPATH/"
fi

# Restore production-only state if it existed.
for f in config.php .installed; do
  if [[ -e "$TMP_BACKUP/$f" ]]; then cp -a "$TMP_BACKUP/$f" "$DEPLOYPATH/$f"; fi
done
if [[ -d "$TMP_BACKUP/uploads" ]]; then
  rm -rf "$DEPLOYPATH/uploads"
  cp -a "$TMP_BACKUP/uploads" "$DEPLOYPATH/uploads"
fi

# Optional first-install bootstrap. It creates a cPanel MySQL DB + DB user only
# when config.php does not exist and UAPI is available to the cPanel account.
if [[ ! -f "$DEPLOYPATH/config.php" ]]; then
  /bin/bash "$REPO_ROOT/deploy/bootstrap_database.sh" "$DEPLOYPATH" "$APP_DOMAIN"
fi

# Run schema migrations after files are in place.
php "$REPO_ROOT/deploy/migrate.php" --root="$DEPLOYPATH" --domain="$APP_DOMAIN"

# Final smoke checks before the deployment is declared live.
php "$REPO_ROOT/deploy/healthcheck.php" --root="$DEPLOYPATH"

# Deployment marker visible to the admin but not public.
printf '%s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" > "$DEPLOYPATH/.deploy-complete"
chmod 600 "$DEPLOYPATH/.deploy-complete" 2>/dev/null || true

echo "Buznnity Lead Manager deployment completed successfully."
