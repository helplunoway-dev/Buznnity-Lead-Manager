#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="${1:-}"
APP_DOMAIN="${2:-}"
CPUSER="${CPANEL_USER:-${USER:-}}"

if [[ -z "$ROOT" || -z "$APP_DOMAIN" || -z "$CPUSER" ]]; then
  echo "bootstrap_database.sh: missing root, domain or cPanel user" >&2
  exit 2
fi

# Use deterministic, short names that remain inside cPanel's database identifier limits.
# cPanel automatically applies the account prefix where required.
DB_BASE="buznitycrm"
DB_USER_BASE="buznityapp"
DB_NAME="${CPUSER}_${DB_BASE}"
DB_USER="${CPUSER}_${DB_USER_BASE}"

# Generate a strong database password without storing it in Git.
DB_PASS="$(php -r 'echo rtrim(strtr(base64_encode(random_bytes(32)), "+/", "-_"), "=");')"

if ! command -v uapi >/dev/null 2>&1; then
  echo "cPanel UAPI is unavailable. Run setup.php once to configure the database, then future deploys will be automatic." >&2
  exit 10
fi

tmpout="$(mktemp)"
trap 'rm -f "$tmpout"' EXIT
if ! uapi --output=json --user="$CPUSER" Mysql create_database name="$DB_BASE" >"$tmpout" 2>&1; then
  grep -qi "already exists\|exists" "$tmpout" || { cat "$tmpout" >&2; exit 11; }
fi
if ! uapi --output=json --user="$CPUSER" Mysql create_user name="$DB_USER_BASE" password="$DB_PASS" >"$tmpout" 2>&1; then
  # A pre-existing user is acceptable only when we already have a generated password file/config.
  # On a truly first install, a conflicting user is unsafe because its password is unknown.
  if ! grep -qi "already exists\|exists" "$tmpout"; then cat "$tmpout" >&2; exit 12; fi
  echo "Database user already exists; preserving deployment-generated database credentials is not possible on a blank config." >&2
  exit 13
fi
if ! uapi --output=json --user="$CPUSER" Mysql set_privileges_on_database user="$DB_USER" database="$DB_NAME" privileges='ALL%20PRIVILEGES' >"$tmpout" 2>&1; then
  cat "$tmpout" >&2
  exit 14
fi

cat > "$ROOT/config.php" <<PHP
<?php
declare(strict_types=1);
const APP_NAME = 'Buznnity Lead Manager';
const APP_DOMAIN = ${APP_DOMAIN@Q};
const BASE_URL = 'https://' . APP_DOMAIN;
const UPLOAD_DIR = __DIR__ . '/uploads/';
const DB_HOST = 'localhost';
const DB_NAME = ${DB_NAME@Q};
const DB_USER = ${DB_USER@Q};
const DB_PASS = ${DB_PASS@Q};
@ini_set('expose_php','0');
date_default_timezone_set('Asia/Kolkata');
\$https=!empty(\$_SERVER['HTTPS']) && \$_SERVER['HTTPS']!=='off';
if(session_status()!==PHP_SESSION_ACTIVE){session_name('blm_session');session_set_cookie_params(['lifetime'=>0,'path'=>'/','secure'=>\$https,'httponly'=>true,'samesite'=>'Lax']);session_start();}
PHP
chmod 0600 "$ROOT/config.php" 2>/dev/null || true

echo "Database and application config created for $APP_DOMAIN."
