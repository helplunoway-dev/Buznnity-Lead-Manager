<?php
declare(strict_types=1);
$options = getopt('', ['root:']);
$root = rtrim((string)($options['root'] ?? dirname(__DIR__)), '/');
$files = ['index.php','db.php','functions.php','setup.php','database.sql','assets/style.css','assets/icons.svg'];
foreach ($files as $file) {
    if (!is_file($root.'/'.$file)) { fwrite(STDERR, "Missing deployment file: $file\n"); exit(30); }
}
require $root.'/config.php';
$pdo = new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset=utf8mb4', DB_USER, DB_PASS, [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);
foreach (['users','leads','brands','schema_migrations'] as $table) {
    $q=$pdo->prepare('SHOW TABLES LIKE ?'); $q->execute([$table]);
    if (!$q->fetchColumn()) { fwrite(STDERR, "Missing required table: $table\n"); exit(31); }
}
echo "Healthcheck PASS\n";
