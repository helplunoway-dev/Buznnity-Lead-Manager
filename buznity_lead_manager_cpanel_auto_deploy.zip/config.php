<?php
declare(strict_types=1);
const APP_NAME = 'Buzznity Lead Manager';
const BASE_URL = '';
const UPLOAD_DIR = __DIR__ . '/uploads/';
const DB_HOST = 'localhost';
const DB_NAME = 'CHANGE_ME';
const DB_USER = 'CHANGE_ME';
const DB_PASS = 'CHANGE_ME';
@ini_set('expose_php','0');
date_default_timezone_set('Asia/Kolkata');
$https=!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off';
if(session_status()!==PHP_SESSION_ACTIVE){session_name('blm_session');session_set_cookie_params(['lifetime'=>0,'path'=>'/','secure'=>$https,'httponly'=>true,'samesite'=>'Lax']);session_start();}
