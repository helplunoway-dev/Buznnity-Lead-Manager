<?php
declare(strict_types=1);
require_once __DIR__.'/functions.php';
login_required();
$fieldId=(int)($_GET['field']??0); $entityId=(int)($_GET['entity']??0);
$st=db()->prepare('SELECT cf.entity_type,cf.field_type,v.value_text FROM custom_fields cf JOIN custom_field_values v ON v.field_id=cf.id AND v.entity_id=? WHERE cf.id=? LIMIT 1');
$st->execute([$entityId,$fieldId]);$r=$st->fetch();
if(!$r||$r['field_type']!=='file'||!$r['value_text']){http_response_code(404);exit('File not found');}
$allowed=false;
if($r['entity_type']==='lead'){$q=db()->prepare('SELECT * FROM leads WHERE id=?');$q->execute([$entityId]);$x=$q->fetch();$allowed=$x?can_view_lead($x):false;}
elseif($r['entity_type']==='brand'){$q=db()->prepare('SELECT * FROM brands WHERE id=?');$q->execute([$entityId]);$x=$q->fetch();$allowed=$x?can_view_brand($x):false;}
elseif($r['entity_type']==='user'){$allowed=is_admin()||((int)current_user()['id']===$entityId);}
if(!$allowed){http_response_code(403);exit('Access denied');}
$base=realpath(UPLOAD_DIR);$path=realpath(UPLOAD_DIR.$r['value_text']);
if(!$base||!$path||strpos($path,$base.DIRECTORY_SEPARATOR)!==0||!is_file($path)){http_response_code(404);exit('File not found');}
$ext=strtolower(pathinfo($path,PATHINFO_EXTENSION));$mime=['jpg'=>'image/jpeg','jpeg'=>'image/jpeg','png'=>'image/png','webp'=>'image/webp','pdf'=>'application/pdf'][$ext]??'application/octet-stream';
header('Content-Type: '.$mime);header('Content-Length: '.filesize($path));header('Content-Disposition: inline; filename="'.basename($path).'"');header('X-Content-Type-Options: nosniff');readfile($path);
