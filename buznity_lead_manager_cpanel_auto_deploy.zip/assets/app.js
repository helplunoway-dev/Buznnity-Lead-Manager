document.addEventListener('DOMContentLoaded',()=>{
  document.querySelectorAll('[data-confirm]').forEach(el=>el.addEventListener('click',e=>{if(!confirm(el.dataset.confirm||'Are you sure?'))e.preventDefault();}));
  document.querySelectorAll('input[type=file]').forEach(input=>input.addEventListener('change',()=>{if(input.files?.[0]?.size>10*1024*1024){alert('Maximum file size is 10MB.');input.value='';}}));
  const sidebar=document.getElementById('sidebar');
  document.querySelectorAll('.mobile-menu').forEach(btn=>btn.addEventListener('click',()=>sidebar?.classList.toggle('open')));
  document.querySelectorAll('.sidebar a').forEach(a=>a.addEventListener('click',()=>sidebar?.classList.remove('open')));
  document.querySelectorAll('[data-check-submit]').forEach(select=>select.addEventListener('change',()=>select.form?.requestSubmit()));
  if('serviceWorker' in navigator){navigator.serviceWorker.register('service-worker.js').catch(()=>{});}
});
