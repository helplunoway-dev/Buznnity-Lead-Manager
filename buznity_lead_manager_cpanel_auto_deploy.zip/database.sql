CREATE TABLE IF NOT EXISTS schema_migrations (
  version VARCHAR(50) NOT NULL PRIMARY KEY,
  applied_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE users (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  full_name VARCHAR(150) NOT NULL,
  username VARCHAR(80) NOT NULL UNIQUE,
  email VARCHAR(190) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('admin','manager','staff') NOT NULL DEFAULT 'staff',
  status ENUM('active','inactive') NOT NULL DEFAULT 'active',
  joining_date DATE NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX(role), INDEX(status)
) ENGINE=InnoDB;

CREATE TABLE user_profiles (
  user_id INT UNSIGNED PRIMARY KEY,
  phone VARCHAR(30), whatsapp VARCHAR(30), alt_phone VARCHAR(30),
  address TEXT, city VARCHAR(100), state VARCHAR(100), country VARCHAR(100),
  photo VARCHAR(255), notes TEXT,
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE brands (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  owner_user_id INT UNSIGNED NULL,
  brand_name VARCHAR(150) NOT NULL,
  business_name VARCHAR(190),
  logo VARCHAR(255),
  cover_image VARCHAR(255),
  phone VARCHAR(30),
  whatsapp VARCHAR(30),
  email VARCHAR(190),
  website VARCHAR(255),
  instagram VARCHAR(255),
  facebook VARCHAR(255),
  youtube VARCHAR(255),
  other_social VARCHAR(255),
  address TEXT, city VARCHAR(100), state VARCHAR(100), country VARCHAR(100),
  description TEXT, notes TEXT,
  status ENUM('active','inactive') DEFAULT 'active',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY(owner_user_id) REFERENCES users(id) ON DELETE SET NULL,
  INDEX(owner_user_id), INDEX(brand_name)
) ENGINE=InnoDB;

CREATE TABLE user_brands (
  user_id INT UNSIGNED NOT NULL,
  brand_id INT UNSIGNED NOT NULL,
  PRIMARY KEY(user_id,brand_id),
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY(brand_id) REFERENCES brands(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE lead_sources (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL UNIQUE,
  active TINYINT(1) DEFAULT 1
) ENGINE=InnoDB;

CREATE TABLE lead_statuses (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL UNIQUE,
  active TINYINT(1) DEFAULT 1,
  sort_order INT DEFAULT 0
) ENGINE=InnoDB;

CREATE TABLE lead_interest_levels (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL UNIQUE,
  active TINYINT(1) DEFAULT 1,
  sort_order INT DEFAULT 0
) ENGINE=InnoDB;

CREATE TABLE leads (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  company_name VARCHAR(190),
  phone VARCHAR(30),
  whatsapp VARCHAR(30),
  email VARCHAR(190),
  address TEXT, city VARCHAR(100), state VARCHAR(100), country VARCHAR(100),
  source_id INT UNSIGNED NULL,
  brand_id INT UNSIGNED NULL,
  service VARCHAR(190),
  status_id INT UNSIGNED NULL,
  interest_id INT UNSIGNED NULL,
  priority ENUM('high','medium','low') DEFAULT 'medium',
  deal_value DECIMAL(14,2) DEFAULT 0,
  assigned_staff_id INT UNSIGNED NULL,
  assigned_manager_id INT UNSIGNED NULL,
  last_contacted DATETIME NULL,
  next_followup DATETIME NULL,
  notes TEXT,
  created_by INT UNSIGNED NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY(source_id) REFERENCES lead_sources(id) ON DELETE SET NULL,
  FOREIGN KEY(brand_id) REFERENCES brands(id) ON DELETE SET NULL,
  FOREIGN KEY(status_id) REFERENCES lead_statuses(id) ON DELETE SET NULL,
  FOREIGN KEY(interest_id) REFERENCES lead_interest_levels(id) ON DELETE SET NULL,
  FOREIGN KEY(assigned_staff_id) REFERENCES users(id) ON DELETE SET NULL,
  FOREIGN KEY(assigned_manager_id) REFERENCES users(id) ON DELETE SET NULL,
  FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE SET NULL,
  INDEX(phone), INDEX(email), INDEX(status_id), INDEX(interest_id), INDEX(brand_id),
  INDEX(assigned_staff_id), INDEX(next_followup), INDEX(created_at)
) ENGINE=InnoDB;

CREATE TABLE lead_activities (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  lead_id INT UNSIGNED NOT NULL,
  user_id INT UNSIGNED NULL,
  activity_type VARCHAR(50) NOT NULL,
  description TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(lead_id) REFERENCES leads(id) ON DELETE CASCADE,
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL,
  INDEX(lead_id), INDEX(created_at)
) ENGINE=InnoDB;

CREATE TABLE lead_followups (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  lead_id INT UNSIGNED NOT NULL,
  assigned_to INT UNSIGNED NULL,
  followup_at DATETIME NOT NULL,
  note TEXT,
  status ENUM('pending','completed','cancelled') DEFAULT 'pending',
  completed_at DATETIME NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(lead_id) REFERENCES leads(id) ON DELETE CASCADE,
  FOREIGN KEY(assigned_to) REFERENCES users(id) ON DELETE SET NULL,
  INDEX(followup_at), INDEX(status)
) ENGINE=InnoDB;

CREATE TABLE lead_notes (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  lead_id INT UNSIGNED NOT NULL,
  user_id INT UNSIGNED NULL,
  note TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(lead_id) REFERENCES leads(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE attachments (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  entity_type ENUM('lead','brand','user') NOT NULL,
  entity_id INT UNSIGNED NOT NULL,
  uploaded_by INT UNSIGNED NULL,
  original_name VARCHAR(255) NOT NULL,
  stored_path VARCHAR(255) NOT NULL,
  mime_type VARCHAR(100),
  file_size INT UNSIGNED DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(uploaded_by) REFERENCES users(id) ON DELETE SET NULL,
  INDEX(entity_type,entity_id)
) ENGINE=InnoDB;

CREATE TABLE checking_types (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  entity_type ENUM('user','brand','lead') NOT NULL,
  name VARCHAR(150) NOT NULL,
  active TINYINT(1) DEFAULT 1,
  sort_order INT DEFAULT 0,
  INDEX(entity_type)
) ENGINE=InnoDB;

CREATE TABLE checks (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  checking_type_id INT UNSIGNED NOT NULL,
  entity_id INT UNSIGNED NOT NULL,
  status ENUM('pending','checked','verified','rejected','needs_update') DEFAULT 'pending',
  checked_by INT UNSIGNED NULL,
  checked_at DATETIME NULL,
  notes TEXT,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY(checking_type_id) REFERENCES checking_types(id) ON DELETE CASCADE,
  FOREIGN KEY(checked_by) REFERENCES users(id) ON DELETE SET NULL,
  UNIQUE KEY entity_check_unique (checking_type_id,entity_id)
) ENGINE=InnoDB;

CREATE TABLE custom_fields (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  entity_type ENUM('user','brand','lead') NOT NULL,
  field_name VARCHAR(150) NOT NULL,
  field_type ENUM('text','number','phone','email','url','date','dropdown','checkbox','textarea','file') DEFAULT 'text',
  options_json TEXT NULL,
  active TINYINT(1) DEFAULT 1,
  sort_order INT DEFAULT 0
) ENGINE=InnoDB;

CREATE TABLE custom_field_values (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  field_id INT UNSIGNED NOT NULL,
  entity_id INT UNSIGNED NOT NULL,
  value_text LONGTEXT,
  FOREIGN KEY(field_id) REFERENCES custom_fields(id) ON DELETE CASCADE,
  UNIQUE KEY(field_entity(entity_id,field_id))
) ENGINE=InnoDB;

CREATE TABLE notifications (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  title VARCHAR(190) NOT NULL,
  message TEXT,
  is_read TINYINT(1) DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX(user_id,is_read)
) ENGINE=InnoDB;

CREATE TABLE audit_logs (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NULL,
  action VARCHAR(100) NOT NULL,
  entity VARCHAR(80) NOT NULL,
  entity_id INT UNSIGNED NULL,
  old_value LONGTEXT,
  new_value LONGTEXT,
  ip_address VARCHAR(45),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL,
  INDEX(entity,entity_id), INDEX(created_at)
) ENGINE=InnoDB;

CREATE TABLE settings (
  setting_key VARCHAR(100) PRIMARY KEY,
  setting_value TEXT
) ENGINE=InnoDB;

INSERT IGNORE INTO lead_sources(name) VALUES
('Facebook'),('Instagram'),('WhatsApp'),('Website'),('Google'),('Referral'),('Advertisement'),('Manual Entry'),('Other');

INSERT IGNORE INTO lead_statuses(name,sort_order) VALUES
('New',1),('Contacted',2),('Follow-up',3),('Qualified',4),('Proposal Sent',5),('Negotiation',6),('Won',7),('Lost',8);

INSERT IGNORE INTO lead_interest_levels(name,sort_order) VALUES
('Very Interested',1),('Interested',2),('Maybe',3),('Follow-up Required',4),('Not Interested',5);

INSERT IGNORE INTO checking_types(entity_type,name,sort_order) VALUES
('brand','Logo Checked',1),('brand','Phone Number Verified',2),('brand','WhatsApp Verified',3),('brand','Website Checked',4),('brand','Instagram Checked',5),('brand','Facebook Checked',6),
('user','Profile Information Verified',1),('user','Phone Verified',2),('user','Email Verified',3),
('lead','Phone Checked',1),('lead','Customer Information Verified',2),('lead','Requirement Checked',3),('lead','Documents Checked',4);

INSERT IGNORE INTO settings(setting_key,setting_value) VALUES
('app_name','Buzznity Lead Manager'),
('currency','INR'),
('timezone','Asia/Kolkata'),
('items_per_page','25'),
('date_format','d M Y'),
('theme_primary','#2563EB'),
('theme_secondary','#1D4ED8'),
('company_name','Buzznity'),
('company_phone',''),
('company_email',''),
('company_address','');
