<?php
declare(strict_types=1);
require_once __DIR__ . '/db.php';
function e(?string $v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function redirect(string $url): never { header('Location: ' . $url); exit; }
function safe_back(string $fallback='?page=dashboard'): never {
    $ref = $_SERVER['HTTP_REFERER'] ?? '';
    $host = $_SERVER['HTTP_HOST'] ?? '';
    $parts = $ref ? parse_url($ref) : false;
    if (is_array($parts) && (empty($parts['host']) || ($parts['host'] ?? '') === $host)) redirect($ref ?: $fallback);
    redirect($fallback);
}
function flash(string $type, string $msg): void { $_SESSION['flash']=['type'=>$type,'msg'=>$msg]; }
function get_flash(): ?array { $x=$_SESSION['flash']??null; unset($_SESSION['flash']); return $x; }
function csrf_token(): string { if(empty($_SESSION['csrf']))$_SESSION['csrf']=bin2hex(random_bytes(32)); return $_SESSION['csrf']; }
function csrf_field(): string { return '<input type="hidden" name="csrf" value="'.e(csrf_token()).'">'; }
function verify_csrf(): void { if($_SERVER['REQUEST_METHOD']==='POST'&&!hash_equals($_SESSION['csrf']??'',$_POST['csrf']??'')){http_response_code(419);exit('Invalid CSRF token');} }
function send_security_headers(): void {
    if(headers_sent())return;
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: SAMEORIGIN');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('Permissions-Policy: camera=(), microphone=(), geolocation=()');
    header("Content-Security-Policy: default-src 'self'; base-uri 'self'; frame-ancestors 'self'; form-action 'self'; object-src 'none'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self' data:; connect-src 'self';");
    $https=!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off';
    if($https)header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
    header('Cache-Control: no-store');
}
function current_user(): ?array {
    static $u=false; if($u!==false)return $u; if(empty($_SESSION['user_id']))return $u=null;
    $st=db()->prepare('SELECT u.*,up.phone,up.whatsapp,up.alt_phone,up.address,up.city,up.state,up.country,up.photo,up.notes FROM users u LEFT JOIN user_profiles up ON up.user_id=u.id WHERE u.id=? LIMIT 1');
    $st->execute([$_SESSION['user_id']]); $user=$st->fetch()?:null;
    if(!$user||$user['status']!=='active'){$_SESSION=[];session_destroy();return $u=null;}
    return $u=$user;
}
function login_required(): void { send_security_headers(); if(!current_user())redirect('?page=login'); }
function role_required(array $roles): void { login_required(); if(!in_array(current_user()['role'],$roles,true)){http_response_code(403);exit('Access denied');} }
function is_admin(): bool { return (current_user()['role']??'')==='admin'; }
function is_manager(): bool { return in_array(current_user()['role']??'', ['admin','manager'], true); }
function is_staff(): bool { return (current_user()['role']??'')==='staff'; }
function user_has_brand(int $brandId,?int $userId=null): bool {
    $userId ??=(int)(current_user()['id']??0); if(!$userId||!$brandId)return false;
    $st=db()->prepare('SELECT 1 FROM brands b LEFT JOIN user_brands ub ON ub.brand_id=b.id AND ub.user_id=? WHERE b.id=? AND (b.owner_user_id=? OR ub.user_id=?) LIMIT 1');
    $st->execute([$userId,$brandId,$userId,$userId]); return (bool)$st->fetchColumn();
}
function can_view_brand(array $brand): bool { $u=current_user(); if(!$u)return false; return $u['role']==='admin'||user_has_brand((int)$brand['id'],(int)$u['id']); }
function can_edit_brand(array $brand): bool { $u=current_user(); if(!$u)return false; return $u['role']==='admin'||($u['role']==='manager'&&user_has_brand((int)$brand['id'],(int)$u['id'])); }
function can_view_lead(array $lead): bool {
    $u=current_user(); if(!$u)return false; if($u['role']==='admin')return true;
    if($u['role']==='staff')return (int)($lead['assigned_staff_id']??0)===(int)$u['id'];
    if((int)($lead['assigned_manager_id']??0)===(int)$u['id'])return true;
    return !empty($lead['brand_id'])&&user_has_brand((int)$lead['brand_id'],(int)$u['id']);
}
function can_edit_lead(array $lead): bool { return can_view_lead($lead); }
function lead_scope_sql(array &$params,string $alias='l'): string {
    $u=current_user(); if(!$u||$u['role']==='admin')return '';
    if($u['role']==='staff'){ $params[]=(int)$u['id']; return "$alias.assigned_staff_id=?"; }
    $params[]=(int)$u['id']; $params[]=(int)$u['id']; return "($alias.assigned_manager_id=? OR EXISTS(SELECT 1 FROM user_brands usb WHERE usb.brand_id=$alias.brand_id AND usb.user_id=?))";
}
function brand_scope_sql(array &$params,string $alias='b'): string {
    $u=current_user(); if(!$u||$u['role']==='admin')return '';
    $params[]=(int)$u['id']; $params[]=(int)$u['id']; return "($alias.owner_user_id=? OR EXISTS(SELECT 1 FROM user_brands usb WHERE usb.brand_id=$alias.id AND usb.user_id=?))";
}
function audit(string $action,string $entity,?int $entityId=null,?string $old=null,?string $new=null): void {
    $u=current_user(); db()->prepare('INSERT INTO audit_logs(user_id,action,entity,entity_id,old_value,new_value,ip_address) VALUES(?,?,?,?,?,?,?)')->execute([$u['id']??null,$action,$entity,$entityId,$old,$new,$_SERVER['REMOTE_ADDR']??null]);
}
function settings(): array {
    $out=[]; foreach(db()->query('SELECT setting_key,setting_value FROM settings') as $r)$out[$r['setting_key']]=$r['setting_value'];
    if(!empty($out['timezone'])&&in_array($out['timezone'],timezone_identifiers_list(),true))date_default_timezone_set($out['timezone']); return $out;
}
function db_stat(string $sql,array $params=[]): int { $st=db()->prepare($sql);$st->execute($params);return(int)$st->fetchColumn(); }
function upload_file(array $file,string $subdir='general'): ?array {
    if(($file['error']??UPLOAD_ERR_NO_FILE)===UPLOAD_ERR_NO_FILE)return null;
    if(($file['error']??0)!==UPLOAD_ERR_OK)throw new RuntimeException('Upload failed.');
    if((int)($file['size']??0)>10*1024*1024)throw new RuntimeException('File is larger than 10MB.');
    $allowed=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp','application/pdf'=>'pdf'];
    $mime=(new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']); if(!isset($allowed[$mime]))throw new RuntimeException('File type not allowed.');
    $subdir=preg_replace('/[^a-z0-9_-]+/i','',trim($subdir,'/'))?:'general'; $dir=UPLOAD_DIR.$subdir.'/'; if(!is_dir($dir))mkdir($dir,0755,true);
    $name=bin2hex(random_bytes(16)).'.'.$allowed[$mime]; if(!move_uploaded_file($file['tmp_name'],$dir.$name))throw new RuntimeException('Could not save file.');
    return ['original_name'=>mb_substr((string)$file['name'],0,255),'stored_name'=>$name,'mime_type'=>$mime,'file_size'=>(int)$file['size'],'path'=>$subdir.'/'.$name];
}
function custom_fields_for(string $entity): array { $st=db()->prepare('SELECT * FROM custom_fields WHERE entity_type=? AND active=1 ORDER BY sort_order,id');$st->execute([$entity]);return $st->fetchAll(); }
function custom_values(string $entity,int $entityId): array { $st=db()->prepare('SELECT cf.id,v.value_text FROM custom_fields cf LEFT JOIN custom_field_values v ON v.field_id=cf.id AND v.entity_id=? WHERE cf.entity_type=? ORDER BY cf.sort_order,cf.id');$st->execute([$entityId,$entity]);$o=[];foreach($st as $r)$o[(int)$r['id']]=$r['value_text']??'';return $o; }
function save_custom_values(string $entity,int $entityId,array $values,array $files=[]): void {
    foreach(custom_fields_for($entity) as $f){
        $id=(int)$f['id']; $type=$f['field_type']??'text'; $val=$values[$id]??'';
        if($type==='file' && isset($files['error'][$id]) && $files['error'][$id]!==UPLOAD_ERR_NO_FILE){
            $file=['name'=>$files['name'][$id]??'file','type'=>$files['type'][$id]??'','tmp_name'=>$files['tmp_name'][$id]??'','error'=>$files['error'][$id]??UPLOAD_ERR_NO_FILE,'size'=>$files['size'][$id]??0];
            $up=upload_file($file,'custom'); $val=$up['path']??$val;
        }
        db()->prepare('INSERT INTO custom_field_values(field_id,entity_id,value_text) VALUES(?,?,?) ON DUPLICATE KEY UPDATE value_text=VALUES(value_text)')->execute([$id,$entityId,is_array($val)?json_encode($val):trim((string)$val)]);
    }
}
function icon_svg(string $name,string $class=''): string {
    $allowed=['dashboard','leads','users','brands','followups','checking','reports','audit','manage','settings','profile','logout'];
    if(!in_array($name,$allowed,true))$name='dashboard';
    return '<svg class="nav-icon '.e($class).'" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><use href="assets/icons.svg#'.e($name).'"/></svg>';
}
function render_custom_field(array $field,string $value=''): string {
    $id=(int)$field['id']; $name='cf['.$id.']'; $label=e($field['field_name']); $type=$field['field_type']??'text'; $safe=e($value);
    if($type==='textarea')return '<label>'.$label.'<textarea name="'.$name.'">'.$safe.'</textarea></label>';
    if($type==='checkbox')return '<label class="check custom-check"><input type="checkbox" name="'.$name.'" value="1" '.($value==='1'?'checked':'').'><span>'.e($field['field_name']).'</span></label>';
    if($type==='dropdown'){
        $opts=json_decode((string)($field['options_json']??''),true); if(!is_array($opts))$opts=[]; $html='<label>'.$label.'<select name="'.$name.'"><option value="">Select</option>';
        foreach($opts as $opt){$opt=(string)$opt;$html.='<option value="'.e($opt).'" '.($opt===$value?'selected':'').'>'.e($opt).'</option>';}
        return $html.'</select></label>';
    }
    if($type==='file')return '<label>'.$label.'<input type="file" name="'.$name.'" accept="image/jpeg,image/png,image/webp,application/pdf">'.($value!==''?'<small class="field-help">A file is already saved. Upload a new file to replace it.</small>':'').'</label>';
    $inputType=in_array($type,['number','email','date','url','phone'],true)?($type==='phone'?'tel':$type):'text';
    return '<label>'.$label.'<input type="'.$inputType.'" name="'.$name.'" value="'.$safe.'"></label>';
}
function page_url(string $page,array $extra=[]): string { return '?'.http_build_query(array_merge(['page'=>$page],$extra)); }
function safe_url(string $url): string { $url=trim($url);if($url==='')return '';if(!preg_match('#^https?://#i',$url))$url='https://'.$url;return filter_var($url,FILTER_VALIDATE_URL)?$url:''; }
function safe_hex_color(string $value,string $fallback): string { $value=trim($value); return preg_match('/^#[0-9a-fA-F]{6}$/',$value)?strtolower($value):$fallback; }
function csv_safe(string $value): string { return preg_match('/^[=+\-@]/',$value)?("'".$value):$value; }
function safe_download_filename(string $value,string $fallback='download'): string { $value=basename($value); $value=preg_replace('/[\r\n"\x00-\x1F\x7F]+/','_', $value)??''; $value=trim($value,'. '); return $value!==''?$value:$fallback; }
