# Buznnity Lead Manager — automatic cPanel deployment

This package supports a Git-based continuous deployment flow:

`GitHub main push → cPanel Git repository → cPanel post-receive hook → .cpanel.yml → file sync → DB migration → healthcheck → live public_html`

cPanel's Git Version Control system supports automatic push deployment when the repository has a checked-in `.cpanel.yml`; its post-receive hook runs the configured deployment tasks. See the official cPanel deployment documentation.

## One-time cPanel setup

1. Open **cPanel → Files → Git Version Control** and create an **empty repository** for this project.
2. Put the repository's exact **Clone URL** into the GitHub Actions secret `CPANEL_GIT_REMOTE`.
3. Put the cPanel server hostname in `CPANEL_SSH_HOST`, the SSH port in `CPANEL_SSH_PORT` (usually 22), and a dedicated deployment private key in `CPANEL_SSH_PRIVATE_KEY`.
4. In `.cpanel.yml`, change `APP_DOMAIN` to the real domain and keep `DEPLOYPATH="$HOME/public_html/"` unless the domain uses a different document root.
5. Push the repository's `main` branch.

## Database behavior

On the first deployment, if `public_html/config.php` does not exist, `deploy/bootstrap_database.sh` attempts to use cPanel UAPI from the cPanel account to create the app database/user and write a protected `config.php`. This requires the hosting account to allow the `uapi` command.

If the hosting account does not allow UAPI from deployment tasks, perform the normal one-time `setup.php` database configuration instead. After that, future code deployments and migrations are automatic.

## Every future update

Commit/push new PHP/CSS/JS/assets or a new file under `migrations/`. The cPanel push deployment hook runs automatically. Existing `config.php`, `.installed`, and `uploads/` are intentionally preserved.

## Safety

Never store cPanel passwords, API tokens, database passwords, SSH private keys, or production `.env` files in Git. GitHub Actions secrets are used for the deployment connection. The deploy script excludes production-only config/uploads from repository sync.
