<?php
declare(strict_types=1);
$root=__DIR__;
$lock=$root.'/.installed';
if(file_exists($lock)){http_response_code(403);exit('Installation is already complete.');}
if(session_status()!==PHP_SESSION_ACTIVE){session_name('blm_install');$https=!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off';session_set_cookie_params(['lifetime'=>0,'path'=>'/','secure'=>$https,'httponly'=>true,'samesite'=>'Lax']);session_start();}
$values=['domain'=>($_SERVER['HTTP_HOST']??''),'db_host'=>'localhost','db_name'=>'','db_user'=>'','db_pass'=>'','admin_name'=>'','admin_username'=>'','admin_email'=>''];
$error='';$success=false;
function h($v):string{return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
function csrf():string{if(empty($_SESSION['install_csrf']))$_SESSION['install_csrf']=bin2hex(random_bytes(32));return $_SESSION['install_csrf'];}
if($_SERVER['REQUEST_METHOD']==='POST'){
    $post=$_POST;
    foreach($values as $k=>$v){$values[$k]=trim((string)($post[$k]??$v));}
    if(!hash_equals($_SESSION['install_csrf']??'',(string)($post['csrf']??'')))$error='Security token expired. Refresh and try again.';
    elseif(!preg_match('/^(?=.{1,255}$)[A-Za-z0-9.-]+(?::\d{1,5})?$/',$values['domain']))$error='Enter a valid domain/host name.';
    elseif($values['db_host']===''||$values['db_name']===''||$values['db_user']==='')$error='Database host, name and username are required.';
    elseif($values['admin_name']===''||$values['admin_username']===''||!filter_var($values['admin_email'],FILTER_VALIDATE_EMAIL)||strlen((string)($post['admin_password']??''))<8)$error='Complete valid Admin details. Password must be at least 8 characters.';
    else{
        try{
            $pdo=new PDO('mysql:host='.$values['db_host'].';dbname='.$values['db_name'].';charset=utf8mb4',$values['db_user'],$values['db_pass'],[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,PDO::ATTR_EMULATE_PREPARES=>false]);
            $schema=file_get_contents($root.'/database.sql');
            if($schema===false)throw new RuntimeException('Database schema file is missing.');
            $schema=preg_replace('/^CREATE DATABASE.*?;\s*/ims','',$schema);
            $schema=preg_replace('/^USE\s+[^;]+;\s*/ims','',$schema);
            $statements=preg_split('/;\s*(?=(?:CREATE TABLE|INSERT IGNORE INTO))/i',$schema,-1,PREG_SPLIT_NO_EMPTY);
            foreach($statements as $sql){$sql=trim($sql);if($sql!=='')$pdo->exec($sql);}
            $st=$pdo->prepare("INSERT INTO users(full_name,username,email,password_hash,role,status) VALUES(?,?,?,?, 'admin','active')");
            $st->execute([$values['admin_name'],$values['admin_username'],$values['admin_email'],password_hash((string)$post['admin_password'],PASSWORD_DEFAULT)]);
            $uid=(int)$pdo->lastInsertId();
            $pdo->prepare('INSERT INTO user_profiles(user_id) VALUES(?)')->execute([$uid]);
            $pdo->prepare("INSERT INTO settings(setting_key,setting_value) VALUES('app_domain',?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)")->execute([$values['domain']]);
            $configTemplate=<<<'PHP'
<?php
declare(strict_types=1);
const APP_NAME = 'Buzznity Lead Manager';
const APP_DOMAIN = __APP_DOMAIN__;
const BASE_URL = 'https://'.APP_DOMAIN;
const UPLOAD_DIR = __DIR__ . '/uploads/';
const DB_HOST = __DB_HOST__;
const DB_NAME = __DB_NAME__;
const DB_USER = __DB_USER__;
const DB_PASS = __DB_PASS__;
@ini_set('expose_php','0');
date_default_timezone_set('Asia/Kolkata');
$https=!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off';
if(session_status()!==PHP_SESSION_ACTIVE){session_name('blm_session');session_set_cookie_params(['lifetime'=>0,'path'=>'/','secure'=>$https,'httponly'=>true,'samesite'=>'Lax']);session_start();}
PHP;
            $config=str_replace(
                ['__APP_DOMAIN__','__DB_HOST__','__DB_NAME__','__DB_USER__','__DB_PASS__'],
                [var_export($values['domain'],true),var_export($values['db_host'],true),var_export($values['db_name'],true),var_export($values['db_user'],true),var_export($values['db_pass'],true)],
                $configTemplate
            );
            if(file_put_contents($root.'/config.php',$config,LOCK_EX)===false)throw new RuntimeException('Could not write config.php.');
            @chmod($root.'/config.php',0600);
            if(file_put_contents($lock,date('c'),LOCK_EX)===false)throw new RuntimeException('Could not create installation lock.');
            $success=true;
        }catch(Throwable $e){error_log('[Buzznity install] '.get_class($e).': '.$e->getMessage());$error='Installation failed. Check the database details and server configuration, then try again.';}
    }
}
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="robots" content="noindex,nofollow,noarchive,nosnippet"><title>Buzznity Lead Manager — First Setup</title><style>*{box-sizing:border-box}body{margin:0;background:#f6f8fb;font-family:system-ui,-apple-system,Segoe UI,sans-serif;color:#172033}.wrap{max-width:760px;margin:35px auto;padding:18px}.card{background:#fff;border:1px solid #e5e9ef;border-radius:20px;padding:26px;box-shadow:0 12px 40px #1018280d}h1{margin:0 0 6px}.muted{color:#667085}.grid{display:grid;grid-template-columns:1fr 1fr;gap:14px}label{font-size:13px;font-weight:700}input{width:100%;margin-top:7px;padding:12px;border:1px solid #d7dde6;border-radius:10px;font:inherit}.full{grid-column:1/-1}.btn{display:inline-block;border:0;border-radius:10px;background:#2563eb;color:#fff;padding:12px 16px;font-weight:800;text-decoration:none;cursor:pointer;width:100%;text-align:center}.alert{padding:12px;border-radius:10px;margin:14px 0}.danger{background:#fee2e2;color:#991b1b}.success{background:#dcfce7;color:#166534}.step{display:flex;gap:10px;align-items:center;margin:20px 0}.num{width:30px;height:30px;border-radius:50%;background:#dbeafe;color:#1d4ed8;display:grid;place-items:center;font-weight:800}@media(max-width:650px){.grid{grid-template-columns:1fr}.full{grid-column:auto}}</style></head><body><div class="wrap"><div class="card"><h1>Buzznity Lead Manager</h1><p class="muted">First-time installation. Enter your domain and cPanel MySQL details.</p><?php if($success):?><div class="alert success"><b>Installation completed successfully.</b><br>Delete or rename <b>setup.php</b> now. Your generated <b>config.php</b> is protected from direct web access.</div><a class="btn" href="./">Open Website</a><?php else:?><?php if($error):?><div class="alert danger"><?=h($error)?></div><?php endif;?><form method="post" autocomplete="off"><input type="hidden" name="csrf" value="<?=h(csrf())?>"><div class="step"><span class="num">1</span><b>Website</b></div><div class="grid"><label class="full">Domain Name<input name="domain" value="<?=h($values['domain'])?>" placeholder="crm.example.com" autocomplete="url" required></label></div><div class="step"><span class="num">2</span><b>MySQL Database</b></div><div class="grid"><label>Database Host<input name="db_host" value="<?=h($values['db_host'])?>" placeholder="localhost" autocomplete="off"></label><label>Database Name<input name="db_name" value="<?=h($values['db_name'])?>" autocomplete="off" required></label><label>Database Username<input name="db_user" value="<?=h($values['db_user'])?>" autocomplete="off" required></label><label>Database Password<input type="password" name="db_pass" autocomplete="new-password"></label></div><div class="step"><span class="num">3</span><b>First Admin</b></div><div class="grid"><label>Full Name<input name="admin_name" value="<?=h($values['admin_name'])?>" autocomplete="name" required></label><label>Username<input name="admin_username" value="<?=h($values['admin_username'])?>" autocomplete="username" required></label><label>Email<input type="email" name="admin_email" value="<?=h($values['admin_email'])?>" autocomplete="email" required></label><label>Password<input type="password" name="admin_password" minlength="8" autocomplete="new-password" required></label></div><br><button class="btn">Test Database &amp; Install</button></form><?php endif;?></div></div></body></html>
