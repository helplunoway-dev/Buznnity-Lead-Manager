# Buznnity Lead Manager migrations

`database.sql` is the bootstrap schema. The deployment system treats an existing bootstrap database as `001_initial`.

For every future database change, add one new file using the next numeric version, for example:

`002_add_lead_score.sql`

The cPanel deployment hook runs `deploy/migrate.php` after files are copied. Applied migrations are recorded in `schema_migrations`, so an already-applied migration is never executed twice.

Keep migrations forward-only and backward-safe. Do not put passwords, API keys, or production configuration in this directory.
