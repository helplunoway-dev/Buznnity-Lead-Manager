BUZZNITY LEAD MANAGER — cPanel / PHP + MySQL

REQUIREMENTS
- PHP 8.0+
- MySQL 5.7+/8.x or compatible MariaDB
- PHP extensions: PDO, PDO_MySQL, FileInfo, OpenSSL, Session
- Apache/cPanel with .htaccess support

INSTALL
1. Upload all files to public_html (or the chosen subdomain folder).
2. Create a MySQL database and database user in cPanel.
3. Open https://YOUR-DOMAIN/setup.php.
4. Enter the domain, DB details and first Admin details.
5. After successful installation, delete or rename setup.php.
6. Keep HTTPS enabled.

MAIN MODULES
Dashboard; Leads; Staff/Managers; Brands; Follow-ups; Activities; Notes; Checking; Custom Fields; Attachments; Notifications; Reports; Audit Logs; Settings; CSV Import/Export.

SECURITY
- CSRF protected state-changing forms
- Prepared SQL statements
- Password hashing
- Hardened session cookies
- Security headers/CSP/HSTS under HTTPS
- Protected config/database files
- MIME-validated uploads with random filenames
- Protected attachment downloads
- Generic production error messages
- CSV formula-injection mitigation

SEO
This is an internal/authenticated CRM. Crawling is intentionally disabled via robots.txt and authenticated pages use noindex. Do not open indexing unless you add a separate public marketing site.

FINAL QA NOTE
The package has passed local PHP syntax/static checks and setup-page HTTP smoke checks. Live cPanel/MySQL production verification must be performed on the target server.

AUTOMATIC DEPLOYMENT
See AUTO_DEPLOY.md. The recommended flow is GitHub main -> cPanel-managed Git repository -> cPanel post-receive deployment -> database migration -> health check -> live public_html.
