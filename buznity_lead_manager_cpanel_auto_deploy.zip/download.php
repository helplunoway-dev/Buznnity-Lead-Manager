<?php
declare(strict_types=1);
require_once __DIR__.'/functions.php';
login_required();
$id=(int)($_GET['id']??0);
$st=db()->prepare('SELECT a.*, l.assigned_staff_id, l.assigned_manager_id, l.brand_id lead_brand_id, b.owner_user_id brand_owner_user_id FROM attachments a LEFT JOIN leads l ON a.entity_type="lead" AND a.entity_id=l.id LEFT JOIN brands b ON a.entity_type="brand" AND a.entity_id=b.id WHERE a.id=? LIMIT 1');
$st->execute([$id]);$f=$st->fetch();
if(!$f){http_response_code(404);exit('File not found');}
$allowed=false;$u=current_user();
if($f['entity_type']==='lead')$allowed=can_view_lead(['assigned_staff_id'=>$f['assigned_staff_id'],'assigned_manager_id'=>$f['assigned_manager_id'],'brand_id'=>$f['lead_brand_id']]);
elseif($f['entity_type']==='brand')$allowed=can_view_brand(['id'=>$f['entity_id']]);
elseif($f['entity_type']==='user')$allowed=is_admin()||((int)$f['entity_id']===(int)$u['id']);
if(!$allowed){http_response_code(403);exit('Access denied');}
$base=realpath(UPLOAD_DIR);$path=realpath(UPLOAD_DIR.$f['stored_path']);
if(!$base||!$path||strpos($path,$base.DIRECTORY_SEPARATOR)!==0||!is_file($path)){http_response_code(404);exit('File not found');}
header('Content-Type: '.($f['mime_type']?:'application/octet-stream'));
header('Content-Length: '.filesize($path));
header('Content-Disposition: inline; filename=\"'.safe_download_filename($f['original_name'],'attachment').'\"');
header('X-Content-Type-Options: nosniff');
readfile($path);
